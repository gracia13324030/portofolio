// ===========================================================================
// DATA — sunting bagian ini untuk mengubah isi portofolio
// ===========================================================================

const PROFILE = {
  name: "Gracia Angelica Sihombing",
  short: "Gracia",
  // TODO: ganti dengan kontak asli kamu
  email: "email@contoh.com",
  linkedin: "linkedin.com/in/nama-kamu",
  github: "github.com/username-kamu",
};

const HERO_DESC =
  "Computer Technology student at Institut Teknologi Del with interests in Web Development, Linux Systems, and Data Analytics. Experienced in developing IoT and web-based systems through academic projects.";

const ABOUT = [
  "Saya mahasiswa D3 Teknologi Komputer angkatan 2024 di Institut Teknologi Del, dengan minat di pengembangan web, sistem Linux, dan analitik data. Lewat proyek akademik, saya terbiasa membangun sistem berbasis IoT dan web.",
  "Saat ini saya sedang mengerjakan Tugas Akhir tentang kriptografi pasca-kuantum pada perangkat ESP32, sambil terus menambah proyek di bidang embedded, jaringan, dan web.",
];
const INTERESTS = ["Web Development", "Linux Systems", "Data Analytics"];

// hue = warna dasar grup (0–360); chip otomatis menyesuaikan tema gelap/terang
const SKILL_GROUPS = [
  { hue: 22, items: ["Java", "Kotlin", "TypeScript", "JavaScript", "Python", "PHP", "C", "C++"] },
  { hue: 190, items: ["React", "Next.js", "Tailwind CSS"] },
  { hue: 120, items: ["Node.js", "Express", "NestJS", "Spring Boot"] },
  { hue: 42, items: ["ESP32", "Arduino", "Sensor INA219", "WebSocket"] },
  { hue: 285, items: ["ECDH", "ML-KEM-512", "Post-Quantum Crypto"] },
  { hue: 345, items: ["DNS", "Mail Server", "HAProxy", "Ansible", "Subnetting / VLSM"] },
];

const PROJECTS = [
  {
    name: "Evaluasi ECDH dan ML-KEM-512 pada ESP32 (Tugas Akhir)",
    period: "Sedang berjalan · tim 3 orang",
    desc: "Membandingkan pembentukan kunci klasik (ECDH) dan post-quantum (ML-KEM-512) langsung pada ESP32-C6 — waktu eksekusi, penggunaan RAM, dan Flash — lalu merancang prototipe dua perangkat yang berkomunikasi lewat Wi-Fi lokal.",
  },
  {
    name: "Smart EcoSystem — Solar Panel Monitoring",
    period: "Proyek Akhir",
    desc: "Dashboard pemantauan panel surya berbasis ESP32 dan sensor INA219. Menampilkan tegangan, arus, daya, dan energi secara real-time lewat WebSocket, lengkap dengan mode simulasi untuk pengujian tanpa perangkat keras.",
  },
  {
    name: "Integrated Network System",
    period: "Tugas Jaringan Komputer",
    desc: "Rancangan sistem jaringan terintegrasi: DNS, web server, mail server, load balancing dengan HAProxy, dan otomasi konfigurasi server menggunakan Ansible.",
  },
  { name: "+ Proyek lainnya menyusul", period: "", desc: "Tambahkan proyek baru di array PROJECTS begitu selesai.", ghost: true },
];

// Isi kalau punya sertifikat, contoh: { name: "Nama Sertifikat", issuer: "Penerbit", year: "2025" }
const CERTIFICATES = [];

// ===========================================================================
// RENDER
// ===========================================================================
const $ = (id) => document.getElementById(id);
const I = {
  mail: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 6-10 7L2 6"/></svg>',
  in: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-4 0v7h-4V8h4v1.6A6 6 0 0 1 16 8Z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/></svg>',
  gh: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 19c-4.3 1.4-4.3-2.5-6-3m12 5v-3.5c0-1 .1-1.4-.5-2 2.8-.3 5.5-1.4 5.5-6a4.6 4.6 0 0 0-1.3-3.2 4.2 4.2 0 0 0-.1-3.2s-1.1-.3-3.5 1.3a12.3 12.3 0 0 0-6.2 0C6.5 2.8 5.4 3.1 5.4 3.1a4.2 4.2 0 0 0-.1 3.2A4.6 4.6 0 0 0 4 9.5c0 4.6 2.7 5.7 5.5 6-.6.6-.6 1.2-.5 2V21"/></svg>',
};

function render() {
  $("heroDesc").textContent = HERO_DESC;
  const links = (cls) => `
    <a class="${cls}" href="mailto:${PROFILE.email}">${I.mail} Gmail</a>
    <a class="${cls}" href="https://${PROFILE.linkedin}" target="_blank" rel="noreferrer">${I.in} LinkedIn</a>
    <a class="${cls}" href="https://${PROFILE.github}" target="_blank" rel="noreferrer">${I.gh} GitHub</a>`;
  $("heroLinks").innerHTML = links("pill");
  $("contactLinks").innerHTML = links("pill");

  $("aboutBody").innerHTML =
    ABOUT.map((p) => `<p>${p}</p>`).join("") +
    `<div class="tags">${INTERESTS.map((t) => `<span>${t}</span>`).join("")}</div>`;

  $("marqueeContainer").innerHTML = SKILL_GROUPS.map((g, i) => {
    const chips = [...g.items, ...g.items]
      .map((n, k) => `<span class="chip" style="--h:${g.hue + (k % g.items.length) * 8}">${n}</span>`)
      .join("");
    return `<div class="marquee-row"><div class="marquee-track ${i % 2 ? "rev" : ""}">${chips}</div></div>`;
  }).join("");

  $("projectsList").innerHTML = PROJECTS.map(
    (p) => `<div class="project reveal ${p.ghost ? "ghost" : ""}">
      <div class="project-top"><h3>${p.name}</h3><span class="project-period">${p.period}</span></div>
      <p>${p.desc}</p></div>`
  ).join("");

  $("certList").innerHTML = CERTIFICATES.length
    ? CERTIFICATES.map((c) => `<div class="cert"><div><b>${c.name}</b><small>${c.issuer} · ${c.year}</small></div></div>`).join("")
    : `<div class="empty">Sertifikat akan ditambahkan di sini.</div>`;

  $("footer").textContent = `© ${new Date().getFullYear()} ${PROFILE.name}`;

  // debu emas melayang di hero
  $("dust").innerHTML = Array.from({ length: 18 }, () => {
    const s = 2 + Math.random() * 3;
    return `<span style="left:${Math.random() * 100}%;top:${20 + Math.random() * 70}%;width:${s}px;height:${s}px;animation-duration:${6 + Math.random() * 8}s;animation-delay:${Math.random() * 8}s"></span>`;
  }).join("");
}

// ===========================================================================
// TEMA gelap / terang
// ===========================================================================
function initTheme() {
  const root = document.documentElement;
  const apply = (t) => {
    root.dataset.theme = t;
    document.querySelectorAll("#themeToggle button").forEach((b) => b.classList.toggle("on", b.dataset.set === t));
    try { localStorage.setItem("theme", t); } catch (e) {}
  };
  let saved = "dark";
  try { saved = localStorage.getItem("theme") || "dark"; } catch (e) {}
  apply(saved);
  document.querySelectorAll("#themeToggle button").forEach((b) => b.addEventListener("click", () => apply(b.dataset.set)));
}

// ===========================================================================
// LANYARD — kartu ID menggantung & bisa diayun
//  • seret kartu: tali mengikuti kursor/jari, lepas → mengayun & mereda
//  • gerakkan kursor melewati kartu: kartu terdorong sesuai kecepatan kursor
//  • klik/tap kartu: kartu berputar-ayun sedikit
// ===========================================================================
function initLanyard() {
  const lan = $("lanyard"), card = $("idCard"), img = $("idImg"), hero = $("home");
  const fb = card.querySelector(".id-fallback");
  img.addEventListener("error", () => (img.style.display = "none"));
  img.addEventListener("load", () => (fb.style.display = "none"));

  const REST = 6; // kemiringan alami kartu (derajat)
  let th = 0, w = 0, dl = 0, dw = 0, thPrev = 0, wPrev = 0;
  let drag = false, moved = false, px = 0, py = 0, last = 0, running = false;
  let mx = 0, my = 0, mt = 0;

  const wake = () => { if (!running) { running = true; last = performance.now(); requestAnimationFrame(tick); } };

  function tick(t) {
    const dt = Math.min(0.032, (t - last) / 1000 || 0.016);
    last = t;
    if (drag) {
      const hr = hero.getBoundingClientRect();
      const ax = lan.offsetLeft + lan.offsetWidth / 2, ay = lan.offsetTop;
      const target = Math.max(-1.1, Math.min(1.1, Math.atan2(px - hr.left - ax, py - hr.top - ay)));
      const nt = th + (target - th) * Math.min(1, dt * 16);
      w = (nt - th) / dt;
      th = nt;
    } else {
      w += (-18 * Math.sin(th) - 1.15 * w) * dt; // gravitasi + redaman
      th += w * dt;
    }
    const acc = (w - wPrev) / dt; wPrev = w;
    dw += (-42 * dl - 3.4 * dw + 0.07 * acc) * dt; // kartu sedikit tertinggal
    dl += dw * dt;

    lan.style.transform = `rotate(${-th}rad)`;
    card.style.transform = `rotate(${REST + (dl * 180) / Math.PI}deg)`;

    if (!drag && Math.abs(th) < 0.002 && Math.abs(w) < 0.01 && Math.abs(dl) < 0.002 && Math.abs(dw) < 0.01) { running = false; return; }
    requestAnimationFrame(tick);
  }

  card.addEventListener("pointerdown", (e) => {
    drag = true; moved = false; px = e.clientX; py = e.clientY;
    card.setPointerCapture(e.pointerId);
    wake();
  });
  card.addEventListener("pointermove", (e) => {
    const r = card.getBoundingClientRect();
    card.style.setProperty("--mx", ((e.clientX - r.left) / r.width) * 100 + "%");
    card.style.setProperty("--my", ((e.clientY - r.top) / r.height) * 100 + "%");
    if (drag) { px = e.clientX; py = e.clientY; moved = true; }
  });
  const release = () => { if (!drag) return; drag = false; if (!moved) { w += 3.2; dw += 6; } wake(); };
  card.addEventListener("pointerup", release);
  card.addEventListener("pointercancel", release);

  // dorongan halus dari gerakan kursor yang melintas dekat kartu
  window.addEventListener("pointermove", (e) => {
    if (drag || e.pointerType === "touch") return;
    const now = performance.now(), dtm = Math.max(8, now - mt);
    const vx = (e.clientX - mx) / dtm; mx = e.clientX; my = e.clientY; mt = now;
    const r = card.getBoundingClientRect();
    const dist = Math.hypot(e.clientX - (r.left + r.width / 2), e.clientY - (r.top + r.height / 2));
    const reach = r.width * 0.95;
    if (dist < reach && Math.abs(vx) > 0.05) { w += vx * 0.9 * (1 - dist / reach); wake(); }
  });

  // masuk dengan ayunan: mulai dari sudut besar lalu mereda
  th = 0.9; wake();
}

// ===========================================================================
// NAV, scroll-spy, reveal, kursor, loader
// ===========================================================================
function initPage() {
  const nav = $("nav"), links = [...document.querySelectorAll("#navLinks a")];
  const secs = links.map((a) => document.querySelector(a.getAttribute("href")));
  const onScroll = () => {
    nav.classList.toggle("scrolled", scrollY > 40);
    let cur = 0;
    secs.forEach((s, i) => { if (s && s.getBoundingClientRect().top < innerHeight * 0.4) cur = i; });
    links.forEach((a, i) => a.classList.toggle("active", i === cur));
  };
  addEventListener("scroll", onScroll, { passive: true }); onScroll();

  const io = new IntersectionObserver((es) => es.forEach((e) => e.isIntersecting && (e.target.classList.add("in"), io.unobserve(e.target))), { threshold: 0.12 });
  document.querySelectorAll(".reveal").forEach((el) => io.observe(el));

  const dot = $("cursorDot");
  addEventListener("pointermove", (e) => {
    dot.style.left = e.clientX + "px"; dot.style.top = e.clientY + "px";
    dot.classList.toggle("hovering", !!document.elementFromPoint(e.clientX, e.clientY)?.closest("a, button, .id-card"));
  });
}

function runLoader() {
  const fill = $("loaderFill"), start = performance.now(), dur = 1700;
  (function step(t) {
    const p = Math.min(1, (t - start) / dur);
    fill.style.width = p * 100 + "%";
    if (p < 1) return requestAnimationFrame(step);
    setTimeout(() => {
      $("loader").classList.add("done");
      document.body.classList.add("ready");
    }, 250);
  })(start);
}

document.addEventListener("DOMContentLoaded", () => {
  render(); initTheme(); initPage(); initLanyard(); runLoader();
});
